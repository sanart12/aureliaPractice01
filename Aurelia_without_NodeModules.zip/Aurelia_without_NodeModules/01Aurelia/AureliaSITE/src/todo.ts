export class Todo {
  done = false;
  constructor(public description: string) { }
}