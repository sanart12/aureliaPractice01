export class Tmp {
    welcome = 'Welcome to the first Aurelia program';
}