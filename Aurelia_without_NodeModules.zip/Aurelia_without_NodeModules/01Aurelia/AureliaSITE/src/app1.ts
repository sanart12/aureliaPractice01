
import {Todo} from './todo';

    export class App123 {
      heading = "Todos";
      todos: Todo[] = [];
      todoTMP: Todo[]=[];
      done=false;
      todoDescription = '';

      addTodo() {
        if (this.todoDescription) {
          this.todos.push(new Todo(this.todoDescription));
          this.todoDescription = '';
        }
      }

      removeTodo(todo) {
        let index = this.todos.indexOf(todo);
        if (index !== -1) {
          this.todos.splice(index, 1);
        }
      }

      completeAll(){
        this.todos.forEach((todo)=>todo.done=true);
      }

      removeAll(flagAll){
        for(let i=0;i<this.todos.length && this.todos.length>0;i++){
          if(flagAll||this.todos[i].done){
          console.log("to be deleted :"+this.todos[i].description+" :: "+this.todos[i].done);
          this.todos.splice(i, 1);
          i--;
          }
        }
      }
    }
