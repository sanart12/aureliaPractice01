let tnr={name:'nag'};

let ctsTngService={
    doTraining:function(){
        console.log(this.name+" giving training to cts");
    }
}


// --------------------------------------------------
// Calling from the 'tnr' Obj
// --------------------------------------------------

var trFunc=ctsTngService.doTraining.bind(tnr);
trFunc();

// --------------------------------------------------
// Calling from the custom Obj which has name
// --------------------------------------------------

var trFunc1=ctsTngService.doTraining.bind({name:'san'});
trFunc1();


// --------------------------------------------------
// Calling from the global Obj
// --------------------------------------------------

var trFunc2=ctsTngService.doTraining.bind();
trFunc2();
//Below is different syntax----------
ctsTngService.doTraining.bind()();
ctsTngService.doTraining.apply();
ctsTngService.doTraining.call();


// ---------------------------
var trFunc4=ctsTngService.doTraining.bind({name1:'san'});
trFunc4();
