// ********** ISSUE WITH THE CODE IS :
//  ITERATING THE ELEMENTS IN A FOREACH LOOP AND TRYING TO DELETE THE ITEMS FROM THE SAME ARRAY.
//  CONCURRENT OPERATION IS NOT WORKING CORRECTLY!!!!!!!!!
// ***** SO TRY THIS EXAMPLE WITH A NEW ARRAY INSTEAD OF USING THE EXISTING ARRAY***********


class ToDo {
    constructor(id = 0, title) {
        this.id = id;
        this.title = title;
        this.completed = false;
    }
}

class TodoService {
    constructor() {
        this.todos = [];
    }
    addTodo(title) {
        //let newTodo=new ToDo((this.todos[this.todos.length].id|this.todos[this.todos.length].id+1,1),title);

        //creating ID

        let newidx = () => {
            if (this.todos.length === 0) { return 1; }
            else { return this.todos[this.todos.length - 1].id + 1; }
        };
        let newTodo = new ToDo(newidx(), title);

        this.todos.push(newTodo);
        //  console.log(this.todos);
    }
    editTodo(id, title) {
        this.todos.forEach((item) => {
            if (item.id === id) {
                item.title = title;
            }
        });

        /* this.todos.forEach(check);
        function check(item)
        {
            if(item.id===id)
            {
                item.title=title;
            }
        } */
    }
    completeTodo(id) {
        this.todos.forEach((item) => {
            if (item.id === id) {
                item.completed = true;
            }
        })
    }
    deleteTodo(id) {

        this.todos.splice(this.todos.findIndex((item) => (item.id === id)), 1);

//return true;
        /* this.todos.forEach(check);
        var temp;
        function check(item)
        {
            if(item.id===id)
            {
                temp=item;
            }
        } */
        //console.log(temp);
        //console.log(this.todos.findIndex(temp));

    }
    completeAll() {
        this.todos.forEach((item) => { item.completed = true; });
/* 
        this.todos.forEach(check);
        function check(item)
        {
            {
                item.completed=true;
            }
        }
 */    }
    clearCompleted() {

 //        this.todos.splice(this.todos.findIndex((item) => (item.completed)), 1);

        this.todos.forEach((item,idx)=>{ 
            console.log("to be deleted: "+item.id);
            this.viewAll();
            
            if(item.completed){
              //  delete this.todos[idx]; // to avoid the concurrent delete issues
//                this.todos.splice(idx,1); //alternate elements missed while delete using the index
             this.deleteTodo(item.id); //alternate elements missed while delete using the index
            }
        });
/*
 
        this.todos.forEach(check);
        function check(item) {
            {
                if (item.completed) {
                    this.todos.deleteTodo(item.id);
                }
            }
        } 
*/
        console.log("### Still trying....");

    }
    viewAll(status) {
        this.todos.forEach((item) => { console.log(item); });

        // this.todos.forEach(check);
        // function check(item)
        // {
        //     {
        //         console.log(item);
        //     }
        // }
    }

}

let newTodo = new TodoService();


newTodo.addTodo('first');
newTodo.addTodo('second');
newTodo.addTodo('three');

newTodo.editTodo(1, 'san');
newTodo.editTodo(2, 'sat');
newTodo.addTodo('first');
newTodo.addTodo('second');

console.log(newTodo);
console.log("-----------Complete All---------------");
newTodo.completeAll();
newTodo.viewAll()
// console.log("-----------delete 1 ---------------");
// newTodo.deleteTodo(1);
//newTodo.viewAll();

console.log("-----------clearCompleted ---------------");
newTodo.clearCompleted();
console.log("-----------View all ---------------");
newTodo.viewAll();
console.log("-----------add new ---------------");
//newTodo.addTodo('first');
//newTodo.addTodo('second');
console.log("## checking ViewAll");
newTodo.viewAll();