//console.log("my Module-1");

var myApp=myApp||{};

function doWork1(){
    myApp.module2.doWork();
    console.log("my Module-1>> doWork");
}-

(function(){
    console.log('Inside new mod1');
      //  myApp.mod2.doWork();
        // myApp.mod3.doWork();    
        var o = {
            doWork: function () {
                console.log('im mod1');
            }
        };
        myApp.module1 = o; // export
        console.log('.......Exiting mod1');
})();
myApp.module1;