//console.log("my Module-2");

var myApp=myApp||{};

function doWork(){
    console.log("my Module-2>> doWork");
}
myApp.module2=doWork;