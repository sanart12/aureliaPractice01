console.log("Welcome to app.js");

// It should return mod1: but will run the function from mod2
var myApp_mod1_call=doWork(); //latest will get replaced the original function defintion

console.log("--------------Alternative way to call the functions from modules--------------------------");
var myApp=myApp||{};
var myApp_mod1_call_NEW=myApp.module2(); //based on the module name module1 or module2 it will call the respective function

var newMyApp=myApp.module1;
console.log(newMyApp);


                                                                                          