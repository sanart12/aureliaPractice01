
import {ToDo} from '../model/Todo';
import {TodoService} from '../service/ToDoServiceJS';


let newTodo = new TodoService();
/* 
newTodo.addTodo('first');
newTodo.addTodo('second');
newTodo.addTodo('three');

newTodo.editTodo(1, 'san');
newTodo.editTodo(2, 'sat');
newTodo.addTodo('first');
newTodo.addTodo('second');

console.log(newTodo);
console.log("-----------Complete All---------------");
newTodo.completeAll();
newTodo.viewAll()
// console.log("-----------delete 1 ---------------");
// newTodo.deleteTodo(1);
//newTodo.viewAll();

//console.log("-----------clearCompleted ---------------");
//newTodo.clearCompleted();
console.log("-----------View all ---------------");
newTodo.viewAll();
console.log("-----------add new ---------------");
//newTodo.addTodo('first');
//newTodo.addTodo('second');
console.log("## checking ViewAll");
newTodo.viewAll();
 */
console.log("-----------Now Press ADD---------------");
let add_btn_action=document.getElementById("add_btn");
add_btn_action.addEventListener('click',()=>{newTodo.addTodo("first"+`${Date.now()}`);newTodo.viewAll();});

let comp_btn_action=document.getElementById("comp_btn");
comp_btn_action.addEventListener('click',()=>{newTodo.completeAll()});

let view_btn_action=document.getElementById("view_btn");
view_btn_action.addEventListener('click',()=>{newTodo.viewAll()});




export {newTodo};