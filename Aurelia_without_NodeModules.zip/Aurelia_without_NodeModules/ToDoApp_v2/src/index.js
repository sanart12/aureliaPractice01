import {ToDo} from './model/Todo'
import {TodoService} from './service/ToDoServiceJS'
import {newTodo} from './view/TodoView'