


function greeter(person: string) {
    return "Hello, " + person;
}

let user = "Sankar";

document.getElementById("localBlk").innerHTML=greeter(user);
