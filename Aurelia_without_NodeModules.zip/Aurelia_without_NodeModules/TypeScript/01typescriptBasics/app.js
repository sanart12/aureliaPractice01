
function greeter(person) {
    return "Hello, " + person;
}
var user = "Sankar";
document.getElementById("localBlk").innerHTML = greeter(user);
